// Hosts we consider "repo sources"
const repoHosts = ["github.com", "gitlab.com", "npmjs.com"];

// Function to check if a URL belongs to one of the hosts
function isRepoUrl(url) {
  try {
    const { hostname, pathname } = new URL(url);

    if (repoHosts.includes(hostname)) {
      // Special handling for GitHub/GitLab: must be /owner/repo
      if (hostname === "github.com" || hostname === "gitlab.com") {
        const parts = pathname.split("/").filter(Boolean);
        return parts.length >= 2; // at least /owner/repo
      }
      return true; // npm and others, just hostname match
    }
  } catch (e) {
    return false; // skip invalid URLs
  }
  return false;
}

// Process all links
document.querySelectorAll("a").forEach((link) => {
  if (isRepoUrl(link.href)) {
    // Add checkmark before the link text
    if (!link.dataset.repoChecked) { // avoid duplicates
      link.dataset.repoChecked = "true";
      const mark = document.createElement("span");
      mark.textContent = "✅ ";
      link.prepend(mark);
    }
  }
});
